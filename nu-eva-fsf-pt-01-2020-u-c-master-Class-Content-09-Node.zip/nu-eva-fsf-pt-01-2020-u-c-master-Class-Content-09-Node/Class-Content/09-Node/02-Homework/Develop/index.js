const questions = [

];

function writeToFile(fileName, data) {
}

function init() {

}

init();
