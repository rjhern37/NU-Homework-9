const api = {
  getUser(username) {

  }
};

module.exports = api;
