var badmath = require("./badmath.js");

console.log(badmath.pie);

console.log(badmath.predictable());
