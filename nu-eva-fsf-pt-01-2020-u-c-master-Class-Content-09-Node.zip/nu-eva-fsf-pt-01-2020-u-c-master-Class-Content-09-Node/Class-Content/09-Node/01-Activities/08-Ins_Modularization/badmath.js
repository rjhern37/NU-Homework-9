var pie = "apple";

var predictable = function(){
  return 1;
}

// module.exports is an object we use to store variables or methods
module.exports = {
  pie: pie,
  predictable: predictable
};
