// run this from the command line using 'node index.js'
console.log("JavaScript outside the browser?!");
