const music = {
  // code here
};

// write code between the <p> tags to output the data from the music object above
const songSnippet = `

`;

const element = document.getElementById("music");
element.innerHTML = songSnippet;
