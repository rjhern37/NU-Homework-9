# Template Literals

* In this activity we will use ES6 template literals display .

## Instructions

* First create a music object following the comments in [Solved/index.js](Solved/index.js).

* Then use template literal syntax to display your objects data. When you open `index.html` you should see the results if completed succesfully.
