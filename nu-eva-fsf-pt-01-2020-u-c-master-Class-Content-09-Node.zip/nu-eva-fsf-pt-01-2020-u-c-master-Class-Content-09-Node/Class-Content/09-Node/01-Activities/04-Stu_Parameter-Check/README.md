# Parameter Check

In this activity, you will write a Node.js command line application that accepts two arguments and returns true if the two values are equal and false if they are not.

## Instructions

* Create a file, `index.js`, in your working directory.

* Write a script using `process.argv` to accept two command line arguments and compare their values.


## Hint(s)

* Start by simply logging the value of each argument to console.

* There's more than one way to solve this problem!

## Bonus

* How many ways can you solve this problem?
