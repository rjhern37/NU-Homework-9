# Hello Node.js

In this activity, you will write and run your first Node.js application.

## Instructions

* Create a file, `index.js`, in your working directory.

* Write JavaScript to log the string, "Hellooo, Node!".

* Then run the program using Node from the command line.

* Confirm that it logged the text as you would expect.

## Hint(s)

* It's just JavaScript.

## Bonus

* What happens when you log `window`? What happens when you try to use `prompt`, `alert`, or `confirm`?
