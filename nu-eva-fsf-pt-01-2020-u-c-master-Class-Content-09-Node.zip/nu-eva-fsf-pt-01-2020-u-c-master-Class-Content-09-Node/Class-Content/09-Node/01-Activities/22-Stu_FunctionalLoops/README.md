# Functional Loops

In this activity we will use the `map` and `filter` methods to solve problems we previously would have used a for loop for.

## Instructions

* Open the [Unsolved](Unsolved) folder and examine the `map.js` and `filter.js` files. Study the examples provided and Complete the problems outlined in the comments.

### Bonus

* Use arrow functions as callbacks here.
