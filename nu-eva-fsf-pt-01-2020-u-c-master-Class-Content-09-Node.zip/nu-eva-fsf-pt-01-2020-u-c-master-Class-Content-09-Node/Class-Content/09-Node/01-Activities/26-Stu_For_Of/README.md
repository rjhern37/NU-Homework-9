## For...of

### Instructions

* Select all of the songs in `index.html` and store them in a variable using JavaScript.

* Iterate through your collection with a for...of and:

    * Add a `class` that changes the color to red (you have to create this class in your CSS file)
    
