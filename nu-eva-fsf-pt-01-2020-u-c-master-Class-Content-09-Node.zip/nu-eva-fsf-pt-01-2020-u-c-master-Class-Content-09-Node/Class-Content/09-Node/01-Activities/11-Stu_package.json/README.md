# package.json

In this activity, you will install the `inquirer` package using `npm`. 

## Instructions

* Run `npm install`. 

    * 🎗 This needs to be your working directory. 

* What happens? How did `npm` know you wanted to install `inquirer`? Where did those additional packages come from?


## Bonus

* How would we create our own `package.json` files? 
