# Object Destructuring

In this activity we will use ES6 object destructuring to pull out object data into variables.

## Instructions

* Open the [Unsolved](Unsolved) folder and write ES6 destructuring code to make all of the console.log's print successfully.


